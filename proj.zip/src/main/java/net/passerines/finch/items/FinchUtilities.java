package net.passerines.finch.items;

public abstract class FinchUtilities extends FinchEquipment{
    public FinchUtilities(String id, int rarity) {
        super(id, rarity);
    }
}
