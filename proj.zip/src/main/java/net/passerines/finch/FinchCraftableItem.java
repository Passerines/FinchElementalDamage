package net.passerines.finch;

import net.passerines.finch.items.FinchItem;

public interface FinchCraftableItem{
    void registerRecipe();
}
